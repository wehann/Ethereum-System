<script>
	if(typeof web3 !== 'undefined'){
		web3 = new Web3(web3.currentProvider);	//设定默认Provider
	}
	else{
		web3 = new Web3(new web3.providers.HttpProvider("http://localhost:8080"));	//设定新的Provider
	}
	
	var infoContract = web3.eth.contract(ABI);	//读入合约ABI
	var info = InfoContract.at(ADDRESS);	//读入合约地址
	
	/*var requestID = new Array();
	var powerExpected = new Array();
	var purchaserDeposit = new Array();
	var auctionStart = new Array();
	var biddingEnd = new Array();
	var revealEnd = new Array();
	var st = new Array();*/
	
	//var request = info.getAllEnabledPurchaserRequest.call();	//获取所有交易信息
	function showRequest(){
		info.getAllEnabledPurchaserRequest(
			function(error, result){
				if(!error){
					for(var i = 0; i < result.lenth; i++){
						$("#info").html("<td>" + i + ' ' + result[i][1] + ' ' + result[i][6] + ' ' result[i][4]+ ' ' + result[i][3] + '</td>');
					}
				}
				else{
					console.error(error);
				}
			}
		)
	}//login界面交易信息表格数据
	
	function buy_submit(){
		$("buy_submit").click(
			function(){
				info.releaseRequest($("#elec_need").var(), $("#time_end").var());
			}	
		)
	}	//发布购电请求
	
	function login(){
		var sname = document.getElementById("sname");	//获取用户地址
		$("#saddr").html(sname);
		
		//var sbal = info.getB.call(sname);	//获取用户余额
		//$("#sbal").html(sbal);
		
		var snum = info.getEBalance.call(sname);	//获取剩余电量
		$("#snum").html(snum);
	}
</script>