//<script language = "javascript" type = "text/javascript">
	/*if(typeof web3 !== 'undefined'){
		web3 = new Web3(web3.currentProvider);	//�趨Ĭ��Provider
	}
	else{
		web3 = new Web3(new web3.providers.HttpProvider("http://localhost:8545"));	//�趨�µ�Provider
	}
	
	var infoContract = web3.eth.contract("[
	{
		"constant": true,
		"inputs": [],
		"name": "getEBalance",
		"outputs": [
			{
				"name": "",
				"type": "address"
			},
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [],
		"name": "getBalance",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getAllEnabledPurchaserRequest",
		"outputs": [
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getAllPurchaserRequest",
		"outputs": [
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "requestID",
				"type": "uint256"
			},
			{
				"name": "price",
				"type": "uint256"
			},
			{
				"name": "randomString",
				"type": "string"
			}
		],
		"name": "sendRealPrice",
		"outputs": [
			{
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "userID",
				"type": "uint256"
			}
		],
		"name": "deleteUser",
		"outputs": [
			{
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "userAddress",
				"type": "address"
			}
		],
		"name": "verifyUser",
		"outputs": [
			{
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "requestID",
				"type": "uint256"
			}
		],
		"name": "transactionAccount",
		"outputs": [
			{
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "requestID",
				"type": "uint256"
			}
		],
		"name": "sendEncryptPriceEnd",
		"outputs": [
			{
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "requestID",
				"type": "uint256"
			}
		],
		"name": "sendRealPriceEnd",
		"outputs": [
			{
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getOwnPurchaseRuquest",
		"outputs": [
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "powerExpected",
				"type": "uint256"
			},
			{
				"name": "endTime",
				"type": "uint256"
			}
		],
		"name": "releaseRequest",
		"outputs": [
			{
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "requestID",
				"type": "uint256"
			},
			{
				"name": "sellerProvide",
				"type": "uint256"
			},
			{
				"name": "hashValue",
				"type": "bytes32"
			}
		],
		"name": "sendEncryptPrice",
		"outputs": [
			{
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [],
		"name": "deposit",
		"outputs": [
			{
				"name": "addr",
				"type": "address"
			},
			{
				"name": "amount",
				"type": "uint256"
			},
			{
				"name": "success",
				"type": "bool"
			}
		],
		"payable": true,
		"stateMutability": "payable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getOwnBidRecord",
		"outputs": [
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			},
			{
				"name": "",
				"type": "uint256[]"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "power",
				"type": "uint256"
			}
		],
		"name": "addUser",
		"outputs": [
			{
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"payable": true,
		"stateMutability": "payable",
		"type": "fallback"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"name": "_from",
				"type": "address"
			},
			{
				"indexed": true,
				"name": "_to",
				"type": "address"
			},
			{
				"indexed": true,
				"name": "value",
				"type": "uint256"
			}
		],
		"name": "Sent",
		"type": "event"
	}
]");	//�����ԼABI
	var info = InfoContract.at(ADDRESS);	//�����Լ��ַ
	
	/*var requestID = new Array();
	var powerExpected = new Array();
	var purchaserDeposit = new Array();
	var auctionStart = new Array();
	var biddingEnd = new Array();
	var revealEnd = new Array();
	var st = new Array();*/
	
	//var request = info.getAllEnabledPurchaserRequest.call();	//��ȡ���н�����Ϣ
	/*function showRequest(){
		info.getAllEnabledPurchaserRequest(
			function(error, result){
				if(!error){
					for(var i = 0; i < result.lenth; i++){
						$("#info").html("<td>" + i + " " + result[i][1] + " " + result[i][6] + " " + result[i][4] + " " + result[i][3] + "</td>");
					}
				}
				else{
					console.error(error);
				}
			}
		)
	}//login���潻����Ϣ��������
	
	function buy_submit(){
		$("buy_submit").click(
			function(){
				info.releaseRequest($("#elec_need").var(), $("#time_end").var());
			}	
		)
	}	//������������
	
	function login(){
		//window.location.href = "../main/main.html";
		
		var sname = document.getElementById("sname");	//��ȡ�û���ַ
		window.open("../main/main.html");
		
		$("#saddr").html(sname);
		
		//var sbal = info.getB.call(sname);	//��ȡ�û����
		//$("#sbal").html(sbal);
		
		var snum = info.getEBalance.call(sname);	//��ȡʣ�����
		$("#snum").html(snum);
		
	}
	*/
	function test(){
		alert("�����С���");
	}
	
	/*function update(){
		showRequest();
		while(1){
			var test = setTimeout(
				function(){
					showRequest();
				}, 300000
			);
		}
	}
//</script>
