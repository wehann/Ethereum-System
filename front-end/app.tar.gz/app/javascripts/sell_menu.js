import { default as Web3} from 'web3';
import { default as contract } from 'truffle-contract'
import metacoin_artifacts from '../../build/contracts/PowerTrade.json'
document.getElementById("sEprice").onclick = function sEPrice(){
function GetRequest() {  
	var url = parent.window.location.search; //»ñÈ¡urlÖÐ"?"·ûºóµÄ×ÖŽ®  
	var theRequest = new Object();  
	if (url.indexOf("?") != -1) {  
   	    	var str = url.substr(1);  
   	//alert(str);  
   	    	var strs = str.split("&");  
   		for (var i = 0; i < strs.length; i++) {  
      			theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);  
       		}  
   	}  
    	return theRequest;  
}  
var request = new Object();  
request = GetRequest();  
var saddr = request['sname'];  
var ebal = request['ebal']; 
//alert(saddr);alert(ebal);  
//document.getElementById("saddr").innerHTML = saddr;
//document.getElementById("sbal").innerHTML = ebal;
var PowerTrade = contract(metacoin_artifacts);
var provider = new Web3.providers.HttpProvider("http://localhost:8545");
PowerTrade.setProvider(provider);
//var contract_address ="0x1550add201927b9c18040c9576d3bd52ba221f9e";
    
var user_account = saddr;
var requestID = document.getElementById("request_id").value;
var sellerProvide = document.getElementById("elec_sell").value;
var sprice = document.getElementById("sprice").value;
var srand = document.getElementById("srand").value;
       var web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));      
var shash = web3.sha3(sprice+srand);

PowerTrade.deployed().then(function(i){
i.sendEncryptPrice(requestID,sellerProvide,shash,{from:user_account,value:sprice,gas:1314222}).then(function(f){
alert(JSON.stringify(f));})});
PowerTrade.deployed().then(function(i){
i.sendEncryptPrice.call(requestID,sellerProvide,shash,{from:user_account,value:sprice,gas:1314222}).then(function(f){
alert(JSON.stringify(f));})});
alert("su");

}
