import { default as Web3} from 'web3';
import { default as contract } from 'truffle-contract'
import metacoin_artifacts from '../../build/contracts/PowerTrade.json'

var PowerTrade = contract(metacoin_artifacts);
var provider = new Web3.providers.HttpProvider("http://localhost:8545");
PowerTrade.setProvider(provider);
//need test
function showRequest()
{
     /*PowerTrade.deployed().then(function(i){
          i.getAllEnabledPurchaserRequest.call({from:user_account,gas:1314222
     }).then(function(result){
             for(var i=0;i<result[result.lenth-1];i++)
                 $(#info).html("<td>"+result[i][0]+' '+result[i][1]+' '+result[i][2]+' '+result[i][3]+' '+result[i][4]+' '+result[i][5]+"</td>" );
            alert("succeed");
     })}); */  
}
/*
var test1 = showRequest();
while(1){
var test = setTimeout(function(){
   showRequest();
}, 300000);
}
*/
       
