import { default as Web3} from 'web3';
import { default as contract } from 'truffle-contract'
import metacoin_artifacts from '../../build/contracts/PowerTrade.json'

        function GetRequest() {  
           var url = parent.window.location.search; //»ñÈ¡urlÖÐ"?"·ûºóµÄ×ÖŽ®  
           var theRequest = new Object();  
           if (url.indexOf("?") != -1) {  
               var str = url.substr(1);  
               //alert(str);  
               var strs = str.split("&");  
               for (var i = 0; i < strs.length; i++) {  
                   theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);  
               }  
           }  
           return theRequest;  
        }  

        var request = new Object();  
        request = GetRequest();  
        var saddr = request['sname'];  
        var ebal = request['ebal']; 
        //alert(saddr);alert(ebal);  
	document.getElementById("saddr").innerHTML = saddr;
        document.getElementById("sbal").innerHTML = ebal;
       
        var PowerTrade = contract(metacoin_artifacts);
        var provider = new Web3.providers.HttpProvider("http://localhost:8545");
        PowerTrade.setProvider(provider);
        var contract_address ="0x1550add201927b9c18040c9576d3bd52ba221f9e";
       var web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));         
	var hash = web3.sha3("5lijiasheng");
	alert("hash:" + hash);

        var user_account = saddr;
        /*PowerTrade.at(contract_address).then(function(instance){
            return instance.addUser(ebal,{from:user_account});
        }).then(function(result){
            console.log(result);
        }).then(function(err){
            console.log(err);
        });*/
        alert("zheng zai deng lu");
        alert(user_account);
        PowerTrade.deployed().then(function(i){
             i.addUser(ebal,{from:user_account,gas:1314222}).then(function(f){
             alert(JSON.stringify(f));})});
        PowerTrade.deployed().then(function(i){
             i.verifyUser.call(user_account,{from:user_account,gas:1314222}).then(function(f){
             alert(JSON.stringify(f));})});
                    
