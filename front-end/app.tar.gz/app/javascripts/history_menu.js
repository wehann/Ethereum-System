import { default as Web3} from 'web3';
import { default as contract } from 'truffle-contract'
import metacoin_artifacts from '../../build/contracts/PowerTrade.json'

function GetRequest() {  
	var url = parent.window.location.search; //»ñÈ¡urlÖÐ"?"·ûºóµÄ×ÖŽ®  
	var theRequest = new Object();  
	if (url.indexOf("?") != -1) {  
   	    	var str = url.substr(1);  
   	//alert(str);  
   	    	var strs = str.split("&");  
   		for (var i = 0; i < strs.length; i++) {  
      			theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);  
       		}  
   	}  
    	return theRequest;  
}  
var request = new Object();  
request = GetRequest();  
var saddr = request['sname'];  
var ebal = request['ebal']; 
//alert(saddr);alert(ebal);  
//document.getElementById("saddr").innerHTML = saddr;
//document.getElementById("sbal").innerHTML = ebal;
var PowerTrade = contract(metacoin_artifacts);
var provider = new Web3.providers.HttpProvider("http://localhost:8545");
PowerTrade.setProvider(provider);
//var contract_address ="0x1550add201927b9c18040c9576d3bd52ba221f9e";

var user_account = saddr;
    

document.getElementById("buy_info").onclick = function changeInfo1()
{
	var table = document.getElementById("info_table");
	var trs=table.getElementsByTagName("tr");
        var c=trs.length;
        while (--c>=0){
        	trs[c].parentNode.removeChild(trs[c]);
	}
 	PowerTrade.deployed().then(function(i){
		i.getOwnPurchaseRuquest.call({from:user_account,gas:1314222}).then(function(f){
               
		alert(JSON.stringify(f));
        var i = 0;
        var j =0;
        alert(f[4]);
        for (;i<f[4];i++)
        {
		var tableRow= table.insertRow(-1); //firefox need -1
                //申购ID，电量，价格，保证金，状态，||数量
 		for (j=0;j<4;j++)
           		tableRow.insertCell(-1);
                var x=table.rows[i].cells;
                for (j=0;j<4;j++)
                {
			var result = f[j];
			alert(result[i]);
			x[j].innerHTML=JSON.stringify(result[i]);
		}			
	}
	})});
}

document.getElementById("sell_info").onclick = function changeInfo2()
{
	var table = document.getElementById("info_table");
	var trs=table.getElementsByTagName("tr");
        var c=trs.length;
        while (--c>=0){
        	trs[c].parentNode.removeChild(trs[c]);
	}
alert("dddd");
 	PowerTrade.deployed().then(function(i){
		i.getOwnBidRecord.call({from:user_account,gas:1314222}).then(function(f){
		alert(JSON.stringify(f));
	var i = 0;
        var j =0;
for (;i<f[5];i++)
        {
		var tableRow= table.insertRow(-1); //firefox need -1
                //申购ID，电量，价格，保证金，状态，||数量
 		for (j=0;j<5;j++)
           		tableRow.insertCell(-1);
                var x=table.rows[i].cells;
                for (j=0;j<5;j++)
                {
			var result = f[j];
			x[j].innerHTML=JSON.stringify(result[i]);
		}			
	}
alert("d");
})});	
}

document.getElementById("sEprice").onclick = function sEPrice(){
	
var requestID = document.getElementById("request_idd").value;
var sprice = document.getElementById("ssprice").value;
var srand = document.getElementById("ssrand").value;
var shash = sprice+srand;
shash = shash.toString();
	PowerTrade.deployed().then(function(i){
	i.sendRealPrice(requestID,shash,sprice,{from:user_account,gas:1314222}).then(function(f){
	alert(JSON.stringify(f));})});  //xuyaoxiugai

        PowerTrade.deployed().then(function(i){
	i.sendRealPrice.call(requestID,shash,sprice,{from:user_account,gas:1314222}).then(function(f){
	alert(JSON.stringify(f));})});  //xuyaoxiugai
}

var requestIDSet =  document.getElementById("request_idd_settle").value;

document.getElementById("requestSettle").onclick = function requestSettle(){
	var requestID = document.getElementById("request_idd").value;
	PowerTrade.deployed().then(function(i){
     		i.transactionAccount(requestID,{from:user_account,gas:6314322}).then(function(f){
 			for(var i=0;i<result.logs.length;i++){
				var log = result.logs[i];
				if(log.event == "Send"){
					var trans={
                                               	"from":log.args._from,
  				            	"to":log.args._to,
						"value":log.args._value.toNumber(),	
					};
 					var t = web3.eth.sendTransaction(trans);
                                        var info = web3.eth.getTransaction(t);
                                        alert(JSON.stringify(info));                               
				}			
			}
				       
 	})});
}

